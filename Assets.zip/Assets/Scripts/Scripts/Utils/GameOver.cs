﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameOver : MonoBehaviour
{
    void EndGame()
    {
        Debug.Log("GAME OVER");
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
